package servletFormulario;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import funciones.Funciones;
/**
 * Servlet implementation class ServletRegistro
 */
public class ServletRegistro extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletRegistro() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		// Variables Generales
		RequestDispatcher dp = null;
		String fullname = request.getParameter("txt_fullname");
		String username = request.getParameter("txt_username");
		String email = request.getParameter("txt_email");
		String pwd = request.getParameter("txt_pwd");
		String confirm_pwd = request.getParameter("txt_confirm_pwd");
		String remember = request.getParameter("remember");
		
		// Variables para error
		String msj_fullname = "";
		String msj_username = "";
		String msj_email = "";
		String msj_pwd = "";
		String msj_confirm_pwd = "";
		String msj_remember = "";
		// Request
		request.setAttribute("servlet_fullname", fullname);
		request.setAttribute("servlet_username", username);
		request.setAttribute("servlet_email", email);
		request.setAttribute("servlet_pwd", pwd);
		request.setAttribute("servlet_confirm_pwd", confirm_pwd);
		request.setAttribute("servlet_remember", remember);
		
		// Validacion
		if(fullname.equals("")) {
			msj_fullname = ("El campo FullName es obligatorio");
		}else if(fullname.matches("[a-zA-Z\\á\\é\\í\\ó\\ú\\Á\\É\\Í\\Ó\\Ú\\ñ\\Ñ\\\s]{3,50}") == false) {
			msj_fullname = ("El campo FullName solo admite letras MIN: 3 MAX: 50");
		}else if(username.equals("")) {
			msj_username = ("El campo Username es obligatorio");
		}else if(username.matches(".{3,20}") == false) {
			msj_username = ("El campo Username admite cualquier caracter hasta MIN: 3 MAX: 20 caracteres");
		}else if(email.equals("")) {
			msj_email = ("El campo email es obligatorio");
		}else if(email.matches(".{3,60}") == false) {
			msj_email = ("El campo email admite cualquier caracter MIN:3 MAX 60");
		}else if(pwd.equals("")) {
			msj_pwd = ("El campo Password es obligatorio");
		}else if(pwd.matches(".{6}") == false) {
			msj_pwd = ("El campo Password debe tener exactamente 6 caracteres");
		}else if(confirm_pwd.equals(pwd) == false) {
			msj_confirm_pwd = ("El campo Confirmar Password debe ser igual al campo Password");
		}else if(remember == null) {
			msj_confirm_pwd = ("Es obligatorio los términos y condiciones");
		}else {
				dp = request.getRequestDispatcher("ExitoFormulario.jsp");
				dp.forward(request, response);
		}
		
		PrintWriter pw = response.getWriter();
		pw.println("<html><head><meta charset=\"utf-8\"><link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css\" rel=\"stylesheet\"></head><body>");
		
		pw.println("<div class='container mt-4'>");
		pw.println("<a href='registro.jsp' class='btn btn-success'>Volver a registrarse</a>");
		pw.println("<br>");
		pw.println("<br>");
		pw.println("<h1>Denegado: Errores detectados<h1>");
		pw.println("<h2 class='bg-primary text-white p-3' >Campo Fullname: " + fullname + "</h2>");
		pw.println("<p class='alert alert-danger'>" + msj_fullname + "</p>");
		pw.println("<h2 class='bg-primary text-white p-3' >Campo Username: " +username + "</h2>");
		pw.println("<p class='alert alert-danger'>" + msj_username + "</p>");
		pw.println("<h2 class='bg-primary text-white p-3' >Campo Email: " + email + "</h2>");
		pw.println("<p class='alert alert-danger'>" + msj_email + "</p>");
		pw.println("<h2 class='bg-primary text-white p-3' >Campo Password: " + pwd + "</h2>");
		pw.println("<p class='alert alert-danger'>" + msj_pwd + "</p>");
		pw.println("<h2 class='bg-primary text-white p-3' >Campo Confirmar Password: " + confirm_pwd + "</h2>");
		pw.println("<p class='alert alert-danger'>" + msj_confirm_pwd + "</p>");
		pw.println("<h2 class='bg-primary text-white p-3' >Campo Terminos y condiciones: "+remember+"</h2>");
		pw.println("<p class='alert alert-danger'>"+msj_remember+"</p>");
		pw.println("</div></body></html>");

		
//		System.out.println(fullname);
//		System.out.println(username);
//		System.out.println(email);
//		System.out.println(pwd);
//		System.out.println(confirm_pwd);
//		System.out.println(remember);
	}
	

}
