package funciones;

public class Funciones {
	public static String saludar() {
		return "Hola mundo";
	}
	public static String generarAlertaHTML(String campo, String valor) {
		String generarHTML = ""
				+ "<div class='alert alert-danger'>\n"
				+ "    <strong>9Danger!</strong> El campo "+ campo +": tiene el siguiente valor. \n"	
				+ "</div>";
		
		return generarHTML;
	}
}
